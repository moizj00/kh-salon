# Task 5 report: every rep-callable function passes a gate

Commit: `2590bed` "tests: a new function cannot skip the device and role gate" (one file: `supabase/tests/function-gates.test.ts`, 521 lines, branch `claude/p1-12-acceptance-guards`, not pushed).
Status: DONE_WITH_CONCERNS (one genuine finding for MJ, see below).

## Result in one paragraph

187 functions can be executed by `authenticated`, all in schema `app`; none by `anon`, none in public, control, supplier_vault or vault_api. 168 call a gate, 14 are allowlisted, 5 are gates themselves (excluded from the sweep and proved by a definition check instead). No function is ungated without a checkable reason. One gate is too weak for one function: `app.warehouse_availability` is readable by an owner or manager without TOTP (AAL1). It is exposed with an `it.fails` "DEFECT CHECK".

## GATES (12) and where each is defined

Declared in the test as `GATE_DEFS` (`GATES: string[]` is derived from it). Module-level constants, not exports, because Biome (`lint/suspicious/noExportsInTest`) forbids exports from a test file; the brief's "Produces" line says exported.

| Gate | Kind | Defined in | What it checks |
|---|---|---|---|
| `app.assert_actor_ready` | raises | `20261024223304_foundation.sql` | active profile; owner/manager need AAL2 (TOTP); rep needs approved device |
| `app.assert_office` | raises | foundation | assert_actor_ready + role owner/manager |
| `app.assert_owner` | raises | foundation | assert_actor_ready + role owner |
| `app.self_ok` | boolean | `20261024232225_device_hardening.sql` | active profile and rep device ok (NOT AAL2, see finding) |
| `app.rep_device_ok` | boolean | foundation, last redefined `20261105230000_audit_fixes.sql` | rep: emailed-code session and approved device matching sha256 of `x-kiran-device`; non-reps true |
| `app.is_office` | boolean | foundation | owner/manager role and AAL2 |
| `app.is_owner` | boolean | foundation | owner role and AAL2 |
| `app.has_vault_grant` | boolean | foundation | owner/manager with vault grant and AAL2 |
| `app.rep_can_reach_salon` | boolean (wrapper) | `20261105100000_invitations_salon_approval.sql` | self_ok + rep holds the salon |
| `app.can_see_salon_money` | boolean (wrapper) | `20261103154528_payments.sql` | is_office or rep_can_reach_salon |
| `app.assert_salon_money` | raises (wrapper) | same file | raises unless can_see_salon_money |
| `app.assert_salon_member` | raises | `20261105150000_requests_portal.sql` | salon portal gate: active membership, emailed-code session, no staff profile (via internal `app.my_salon_id`) |

7 of the 12 are not executable by `authenticated` (assert_actor_ready, assert_office, assert_owner, rep_can_reach_salon, can_see_salon_money, assert_salon_money, assert_salon_member); the other 5 (is_office, is_owner, has_vault_grant, self_ok, rep_device_ok) are, and are the "5 gates" excluded from the sweep.

### How a function that only calls ANOTHER gated function is treated
It does NOT count. Only the 12 helpers count. Each wrapper (`rep_can_reach_salon`, `can_see_salon_money`, `assert_salon_money`) is itself proved, one hop, by the definition check (`GATE_GAPS`: the body must still call the gate it wraps), so the chain is explicit. A business function that calls an internal helper with no gate (for example `app.record_payment`) is reported.

### How "calls a gate" is decided
SQL regex on `prosrc` after stripping `/* */` and `--` comments and then string literals: `app.<gate>[[:space:]]*(`. A gate named in a comment or an error message does not count; a look-alike name (`app.assert_office_not(`) does not count; a boolean gate whose call is thrown away with `PERFORM` does not count (a raising gate with PERFORM is the normal use and does).

### Gate integrity (`GATE_GAPS`)
Each gate must exist exactly once in schema app (a second overload fails) and its body must still contain the parts that make it a gate (for example assert_actor_ready must still call user_role, is_aal2, rep_device_ok and raise_denied; rep_device_ok must still read `public.device` with `status = 'approved'`). Tested against planted weakened, dropped and overloaded gates.

## Sweep numbers (real, from the catalog)
- Callable by `authenticated` or `anon` in the five schemas: 187 (all `app`).
- Gated (call a gate): 169 in total = 168 business/read functions + `self_ok` (it calls rep_device_ok).
- Allowlisted: 14.
- Gates excluded from the sweep: 5 (is_office, is_owner, has_vault_grant, self_ok, rep_device_ok). 168 + 14 + 5 = 187.
- anon-callable: 0 (any schema). The test "anon can execute no function in our schemas" pins it, so a deliberate anon grant needs this file changed in review.
- Floors in the test: at least 150 callable, 100 gated, and five sample functions (office_set_sku_price, rep_record_payment, owner_set_role, my_day, rep_check_in) must be found and gated.
- Note: `verifier-attacks.test.ts` already pins the exact list of names `authenticated` may execute (MJ approval trail). This file is complementary: it checks each of those calls a gate.

## ALLOWLIST (14), each with a `proof` that is checked against the body
Key = `schema.name(argument types)` as the catalog prints it, so a new overload is not covered. The test fails when an entry is stale (function gone, or now calls a gate), is a gate, is repeated, or when a `proof` regex no longer matches the body.

Way in before a device/profile exists:
1. `app.register_device(text,text,text)`: creates the caller's own pending device row; only `approve_device` (gated by `assert_office`) can approve. Proof: `user_role() is null` check, `rep_session_ok`, `insert into public.device`.
2. `app.my_session()`: how the phone learns its device status on an unapproved device (device-hardening 0004 item 3). Own row only (`p.id = auth.uid()`), rep only on emailed-code session.
3. `app.redeem_invitation(text)`: creates the profile or salon membership, so no profile exists to gate on. Needs emailed-code session, token hash, own confirmed email; refuses a login that already has a staff profile. Proof: `session_proved_email`, `invitation_hash`, "already has a staff account".
4. `app.invitation_preview(text)`: read-only, same proof, null for anyone else.
5. `app.salon_apply(uuid,text,text,salon_type,text)`: salon signup request; same emailed-code proof; refuses staff; never creates a user_profile.
6. `app.salon_me()`: own active membership only (`user_id = auth.uid()`), emailed-code session.
7. `app.salon_login_status()`: own membership or own signup request only, emailed-code session.

Refuses everyone:
8. `app.create_order(uuid,uuid,plan_code,delivery_mode,jsonb,uuid,timestamptz)`: retired by D-30; first statement is `raise exception ... errcode = '42501'`. Proof checks that. A separate test calls it as owner, manager, rep and anon and requires 42501 and the "reps no longer place orders" message.

The gates' own primitives (a value about the caller's own session, no business table):
9. `app.user_role()` (one row by `auth.uid()`), 10. `app.is_aal2()` (reads `auth.jwt()`), 11. `app.is_rep()` (role-only boolean), 12. `app.request_device_id()` (echoes `x-kiran-device`).

RLS helpers returning the caller's own ids (no device test of their own):
13. `app.my_bag_id()`, 14. `app.my_territory_ids()`: rep only, emailed-code session, own rows. Reason is backed by a test: every policy that references `my_bag_id`, `my_territory_ids` or `is_rep` also requires `self_ok` (about 19 policies when I probed them; floor 10 in the test). Observation: they have no device check themselves; the value is a uuid of the caller's own bag or territories.

## Genuine findings for MJ

1. **`app.warehouse_availability()` is readable by an owner or manager without TOTP (AAL1).** Its only filter is `app.self_ok() and app.user_role() is not null`. `self_ok` is the rep DEVICE gate: `rep_device_ok` returns true for every non-rep, so `self_ok()` is true for an office session at AAL1. Verified non-vacuously: with a planted active SKU and a warehouse location, manager at AAL2 sees 1 row, the same manager at AAL1 sees 1 row (`self_ok` true, `is_office` false, `aal` aal1). It exposes the available quantity per SKU of the warehouse. Low severity (reps can read the same), but it contradicts SEC-02 "no AAL2, no office powers" and no test pins it. Exposed as `it.fails("DEFECT CHECK: an office session without TOTP (AAL1) must not read app.warehouse_availability()")`, with a plain baseline test (AAL2 sees the planted row) so the fails-test cannot pass for the wrong reason. When fixed (for example require `is_office()` or `user_role() = 'rep'`), turn it into a plain `it()`.
   - Class of problem: any new function whose only gate is `self_ok` and that has no rep-role condition has the same hole. The sweep cannot see this (stated in the file header under "Does NOT prove"); the only such function found today is this one.
2. Known and accepted, not a finding: `app.may_read_product_images()` is true for office at AAL1 (`self_ok() or salon member`), deliberately pinned by `catalogue-prices.test.ts` (`MANAGER_AAL1` expected true).
3. Observation: `my_bag_id` and `my_territory_ids` carry no device check (allowlisted, reason checked by the policy test). Not a defect today.

Zero ungated functions without a reason.

## Commands and real output

All tests were run with `pnpm exec vitest run --config supabase/tests/vitest.config.ts function-gates` (embedded Postgres bound its port without trouble; DATABASE_URL was never read).

### RED (honest label)
Produced from a temporary copy `function-gates-red.test.ts` of the finished file with `ALLOWLIST = []` (deleted afterwards), not from the committed file's history. 13 tests, 2 failed:
```
× every function that authenticated or anon can execute calls a gate, or is on the allowlist with a reason
  + app.create_order(uuid, uuid, plan_code, delivery_mode, jsonb, uuid, timestamp with time zone)
  + app.invitation_preview(text)  + app.is_aal2()  + app.is_rep()  + app.my_bag_id()  + app.my_session()
  + app.my_territory_ids()  + app.redeem_invitation(text)  + app.register_device(text, text, text)
  + app.request_device_id()  + app.salon_apply(uuid, text, text, salon_type, text)
  + app.salon_login_status()  + app.salon_me()  + app.user_role()
```
That is exactly the expected 14, the reason the sweep fails without an allowlist. The second failure was a bug in my test, not in the product: the "second overload" case planted `app.is_aal2(int)`, but `is_aal2` is not in GATE_DEFS, so GATE_GAPS rightly did not report it (`expected [] to include 'app.is_aal2'`). Switched to `app.self_ok(int)`.

### First GREEN attempt: failed
```
× every allowlist entry still exists, still calls no gate, and its reason still holds in the body
  - "app.register_device(text, text, text): its reason no longer holds, body lacks
     /app[.]user_role[[:space:]]*[(][[:space:]]*is[[:space:]]+null/"
```
Cause: my proof regex was built with `callOf("app.user_role")`, which ends at `(`, so the `)` was missing. Fixed to `app[.]user_role[(][)][[:space:]]+is[[:space:]]+null`. This is also evidence that the proof check really detects a reason that does not hold.

### Biome and tsc
`pnpm exec biome check --write supabase/tests/function-gates.test.ts` first reported "Do not export from a test file" (4 errors) -> removed the `export`s. Then "No fixes applied". `pnpm exec tsc -p supabase/tests/tsconfig.json --noEmit` exit 0.

### Final GREEN (verbose run)
```
 Test Files  1 passed (1)
      Tests  14 passed | 1 expected fail (15)
   Duration  37.64s
```
The one expected fail is the DEFECT CHECK above. Tests: gate definitions; sweep not vacuous; sweep; allowlist stale/proof; anon none; create_order refuses every persona; RLS helper policies; planted: ungated / each gate kind / discarded boolean / look-alike / comment / string / escaped quote / other schemas / anon grant / not executable / language sql; weakened-gate; allowlist-check unit cases; baseline + DEFECT CHECK for warehouse_availability.

## Self-review
- Test-first: yes for the sweep (RED above); the planted-guard tests were written together with the guards and pass by design, but each asserts both directions (reported and not reported).
- Function list and allowlist sigs come from the catalog; the 14 sigs were read with `oidvectortypes` from a probe, not guessed.
- Regexes are Postgres ARE and run in the database, so planted functions go through the very same query as the real sweep.
- Files: only `supabase/tests/function-gates.test.ts` was created or changed; scratch probe tests were deleted; `git status` clean after the commit.
- The advisor review caught the `self_ok`-without-TOTP gap (my first version counted `self_ok` as a full gate); it is now documented in the header and tested.

## Concerns
1. Finding 1 above needs MJ's decision (fix in a migration, which I was not allowed to do here).
2. Call-presence is the limit of this kind of sweep: a gate called in one branch only, or a boolean result used wrongly, still passes. Documented in the file header; behaviour is covered by the per-module tests.
3. Environment: on this machine vitest alternates between "No test files found" / "Unknown Error ... close timed out after 10000ms" and a normal run, usually right after the file changed, so most results came from a rerun (the filter `function-gates.test` was more reliable than `function-gates`). A passing run is a full run.
4. The new `it.fails` in the committed file will go red the day the defect is fixed, by design: it then has to become a plain `it()`.

---

# Fix round 1 (commit 23807fa "tests: a device check alone does not pass an office-reachable function")

## What changed (only supabase/tests/function-gates.test.ts)

**G1, structural TOTP rule.** `app.self_ok` and `app.rep_device_ok` are now marked `deviceOnly` in `GATE_DEFS`. The sweep now has three outcomes per callable function:
- passes on a FULL gate (every other gate): gated;
- passes on a device-only gate AND carries a rep-only marker in the same body: gated;
- passes on a device-only gate alone, no marker: reported by the new `DEVICE_ONLY` query, unless it is in `DEVICE_ONLY_EXCEPTIONS`;
- calls no gate at all (a PERFORM-discarded device gate counts as none): reported by `UNGATED` as before.

Rep-only markers (`REP_ROLE` regex on the comment-stripped body, plus three helper calls), verified against the latest definitions:
- `app.user_role() = 'rep'` or `app.user_role() is distinct from 'rep'` (the refusing form used by `my_cash_position`, `my_handovers`, `my_signature_status`). `<> 'rep'`, a comment or a string do not count (planted cases).
- `app.my_bag_id()` and `app.my_territory_ids()`: latest definition in `20261105230000_audit_fixes.sql` returns rows only when `app.user_role() = 'rep'`; the definition check (`MARKER_DEFS` in `GATE_GAPS`) fails if that test disappears.
- `app.rep_can_reach_salon()`: latest definition `20261105100000_invitations_salon_approval.sql` tests `user_role() = 'rep'`; I added that regex to its `needs`. It stays a full gate (it is rep-only and device-checked), so it is not a device-only gate.
- I did not use `app.is_rep()` as a marker (no function body calls it; only policies do).

`DEVICE_ONLY_EXCEPTIONS` (named, with status; a stale entry fails):
- `app.warehouse_availability()` DEFECT (the it.fails DEFECT CHECK stays).
- `app.may_read_product_images()` ACCEPTED, pinned by catalogue-prices.test.ts ("pictures: who may read the product-images bucket", MANAGER_AAL1 expected true).

New tests: sweep "device-only gate must carry a rep-only marker or be a named exception"; "exceptions still exist and still pass on a device-only gate alone" (plus the two statuses); planted cases (12) for a function gated only by `app.self_ok()`: reported (self_ok alone, rep_device_ok alone, marker only in a comment, marker only in a string, `<> 'rep'`), not reported (`user_role() = 'rep'`, the refusing form, my_bag_id, my_territory_ids, rep_can_reach_salon, self_ok + is_office, self_ok + assert_office); `perform app.self_ok()` is reported as ungated; the exception check is tested with a gone function and a properly gated one (`app.my_day()`); the "each kind of gate" test now also asserts that only self_ok and rep_device_ok are reported as device-only. The header comment no longer says the sweep misses this.

**G2, DEFECT CHECK flips for both fix shapes.** `warehouseRowsAt` now catches SQLSTATE 42501 and returns 0, so a fix that makes `app.warehouse_availability` raise at AAL1 turns the `it.fails` red, same as a fix that returns no rows. Any other error is rethrown; a 42501 in the shared setup would make the AAL2 baseline test (expects 1 row) fail, so it cannot hide. Not covered by a planted test (the fix cannot be simulated without changing the migration).

## Command and real output
`pnpm exec vitest run --config supabase/tests/vitest.config.ts function-gates.test --reporter=verbose` (reran after "No test files found" as before; only this file).
```
 Test Files  1 passed (1)
      Tests  18 passed | 1 expected fail (19)
   Duration  40.30s
```
biome check clean, `tsc -p supabase/tests/tsconfig.json --noEmit` exit 0.

RED for G1 (temporary copy with the exception list emptied, deleted afterwards; 1 failed, 17 passed, 1 expected fail):
```
× every function that passes only on a device-only gate (self_ok, rep_device_ok) also carries a rep-only marker, or is a named exception
  + "app.may_read_product_images()",
  + "app.warehouse_availability()",
```

## Numbers (from the same temporary copy, catalog counts)
- 187 callable functions; 5 are gates themselves; 182 swept.
- 155 pass on a full gate (some also carry a device gate or marker).
- 11 pass ONLY on a device-only gate plus a rep marker (no full gate): my_areas, my_bag, my_day, my_signature_status, my_cash_position, my_route, my_pending_issues, my_issue_skus, my_handovers, my_salon, my_salons. (19 functions have a device gate and a marker in total; 8 of them also have a full gate.)
- 2 pass on a device-only gate with no marker: the two named exceptions.
- 14 allowlisted. 155 + 11 + 2 + 14 = 182.

## Findings
No new finding. Applying the rule surfaced exactly the two functions already known: `app.warehouse_availability` (DEFECT, unchanged finding for MJ) and `app.may_read_product_images` (accepted, pinned). Total genuine findings: 1 (warehouse_availability at AAL1).

## Concerns
- Markers are read as text, like gates: a `user_role() = 'rep'` that sits on a path that does not guard the data would pass. Behaviour stays with the per-module tests.
- The exception list means a SECOND defect of the same shape would fail the sweep until someone names it, which is the intent.
