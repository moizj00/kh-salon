# Task 3 report: the acceptance index

Status: DONE_WITH_CONCERNS. Commit `ef16247` "tests: launch security criteria mapped to evidence" on `claude/p1-12-acceptance-guards`. Only three files were added: `supabase/tests/helpers/launch-acceptance.ts`, `supabase/tests/launch-acceptance.test.ts`, `docs/runbooks/launch-security-acceptance.md`.

## Design as built

- Data and guard are in the non-test module `supabase/tests/helpers/launch-acceptance.ts` (Biome forbids exports from test files). It exports `Evidence`, `Entry`, `Status`, `REPO_ROOT`, `ACCEPTANCE` (14 criteria), `ADDITIONAL` (2 extra controls), `checkEvidence(entry, root): string[]` and `statusOf(entry)`.
- Evidence kinds: `test`, `ci`, `manual`, `blocked`, plus the new `defect`.
  - `test`: ref `path::exact title`. The title must appear as a quoted string literal that is the first argument of an `it`/`test`/`describe` call (so a comment or an `expect("...")` does not count), and that call must not be `.skip`, `.skipIf`, `.todo`, `.runIf` or `.fails`.
  - `defect`: ref `path::exact title` of an `it.fails` check. It is reported like `blocked` (never proof). It fails the index test when the title is no longer an `it.fails` (defect fixed, row must go).
  - `ci`: ref is the job KEY under `jobs:` in `.github/workflows/ci.yml` (not the display name, which can change), optionally `job::text` requiring the job block to contain that text. Used as `typecheck::scripts/service-role-scan.mjs`. The display name is "typecheck + service-role scan".
  - `manual`: a repo path that exists. No criterion uses it today (the drill runbook does not exist, so 06.10.7 is blocked, per ruling).
  - `blocked`: non-empty task id or note.
- Status per criterion: `defect` if any defect entry; else `blocked` if nothing proves; else `partial` if some entry is blocked; else `met`. Blocked and defect never count as proof.
- "Reported as blocked, never passing": each blocked and defect entry produces an `it.todo` (reporter shows them as todo, 11 of them), and a test pins the set of blocked `criterion | ref` pairs and the set of defect criteria to explicit lists in the test file.
- Runbook tests: table rows equal the criteria in order; each wording is a verbatim substring of its source document (doc 06, doc 07, or docs/ACTIVITY.md for ADD rows; markdown asterisks and backticks ignored); status cell equals computed status; each criterion section in the runbook contains every reference of its evidence.
- Guard tests (planted, in a temp tree): valid refs accepted; one message for each of 13 broken-reference cases (missing file, absent title, skipped, todo, commented-out, it.fails cited as a test, malformed ref, live test cited as defect, missing CI job, CI job lacking text, missing manual file, empty blocked ref, unknown kind); empty evidence fails; status function behaviour.

## Criterion to evidence table as built

| Criterion | Status | Evidence (test files; titles are in the runbook and helper) |
|---|---|---|
| 06.10.1 RLS matrix, rep territory A vs B | met | rls-matrix (3 static titles), schema-hygiene (RLS enabled AND forced), salons (2), reverify3 list-dump, verify-slices-1-3 (3: masked my_salon, territory end, reveal_phone), crm-attacks (masks phone numbers), rep-detail-documents (no unmasked phone), rep-readonly-timelines (other territory 42501) |
| 06.10.2 append-only | met | append-only-sweep (7 titles incl. the `%s:` per-role refusal), foundation (audit_event append-only), salons (notes, stage events, reveals refuse UPDATE/DELETE/TRUNCATE) |
| 06.10.3 TOTP and approved device | DEFECT | device-guard (2), foundation (5: unapproved device, suspended rep, revoked id dead, owner AAL1, vault grant AAL), verify-slices-1-3 (rep cannot approve own phone), function-gates (5 sweep titles), plus `defect`: function-gates `DEFECT CHECK: an office session without TOTP (AAL1) must not read app.warehouse_availability()` |
| 06.10.4 vault via API; access log and digest | partial | schema-hygiene (2), verifier-attacks (1); blocked `P1-05` (access log, digest) |
| 06.10.5 audit chain; mirror | partial | foundation (3: verifies, tamper detection, no app role executes), schema-hygiene (audit trigger everywhere, owner-only select); blocked `audit mirror (no task id yet, MJ assigns)` |
| 06.10.6 offboarding | blocked | `P1-08` |
| 06.10.7 restore drill | blocked | `P1-12 PR C` |
| 06.10.8 scans | partial | ci `typecheck::scripts/service-role-scan.mjs`; service-role-scan.test (3); blocked `P1-12 PR A` (dependency audit and secret scan, one entry) |
| 07.5.1 rep token | met | schema-hygiene, verifier-attacks, reverify3 §7.2 |
| 07.5.2 manager without/with grant | partial | verifier-attacks (has_vault_grant false), foundation (vault grant matrix); blocked `P1-05` |
| 07.5.3 to 07.5.5 | blocked | `P1-05` each |
| 07.5.6 revoke bites next request | partial | foundation (revoking the manager's vault grant takes effect on the next request); blocked `P1-05` |
| ADD.1 maker cannot approve own request (H-12) | met | foundation (3) |
| ADD.2 backdated client time vs server time (H-09) | met | crm-attacks (3), payments (1), verifier-attacks (1), verify-slices-1-3 (1) |

Counts over the 14 criteria: met 3 (06.10.1, 06.10.2, 07.5.1); partial 5 (06.10.4, 06.10.5, 06.10.8, 07.5.2, 07.5.6); blocked 5 (06.10.6, 06.10.7, 07.5.3, 07.5.4, 07.5.5); defect 1 (06.10.3). Blocked-entry set (10 entries) is pinned in the test.

## The six coordinator items

1. No rep or un-granted manager token reaches supplier_vault: 07.5.1 and 07.5.2 (tests cover every application role including manager; `has_vault_grant` false for reps, AAL1 office, suspended, manager after revoke), also 06.10.4. Found, cited.
2. UPDATE/DELETE fail on append-only for all roles: 06.10.2. Found, cited.
3. Rep tokens cannot read unmasked phones or other-territory salons: 06.10.1 (mapped there, no new row). Found, cited.
4. Maker cannot approve own request: ADD.1 (doc 06 section 10 has no row for it; H-12 in ACTIVITY.md). Found, cited.
5. Backdated client timestamp governed by server time: ADD.2 (H-09). Found, cited.
6. Audit chain verifies: 06.10.5 (mirror half blocked). Found, cited.

All six have existing tests. No behavioural test was written.

## Commands and output

RED (stub helper with empty `ACCEPTANCE`, no runbook), `pnpm exec vitest run --config supabase/tests/vitest.config.ts launch-acceptance`:

```
 Test Files  1 failed (1)
      Tests  9 failed | 5 passed (14)
```
Failures were real: criteria list empty, planted-reference guard returned no messages, status function wrong, pinned blocked and defect lists mismatched, and `ENOENT docs/runbooks/launch-security-acceptance.md` for the four runbook tests. The 5 that passed in RED are vacuous with a stub (empty data, valid-planted-case). Full RED text: `task-3-red-full.txt` in this folder.

GREEN (same command, final code):
```
 Test Files  1 passed (1)
      Tests  14 passed | 11 todo (25)
```
Verbose reporter shows the 11 todo lines, for example `06.10.3 DEFECT open: supabase/tests/function-gates.test.ts::DEFECT CHECK: ...` and `06.10.4 BLOCKED on P1-05: not proven`. Full text: `task-3-green-full.txt`.

`pnpm exec biome check --write` on the two TS files: clean after fixing five `useIterableCallbackReturn` errors. `pnpm exec tsc -p supabase/tests/tsconfig.json --noEmit`: no output, exit 0. The whole suite was not run; no database or DATABASE_URL was used by my file (global setup still started the embedded Postgres, which worked).

## Self-review and concerns

1. Every real citation resolved on the first GREEN run, but the check is syntactic: it proves the title exists as a live test, not that the test passed. Passing is the suite's job.
2. 07.5.1 is `met` although `vault_api` has no functions yet, so "every vault_api function refuses" is vacuous. Said in the runbook; P1-05 must extend the check. Decision for MJ if he prefers it `partial`.
3. 06.10.3: the database-side AAL2 gate is tested, but enrolling TOTP and refusing sign-in without it is a GoTrue setting no test covers. Said in the runbook. Together with the open `app.warehouse_availability` defect, 06.10.3 must not be read as met.
4. The RLS matrix names its per-table cases from data, so only its three static titles are citable. The runbook says so.
5. The `ci` evidence proves the job is defined and runs the scan script; it cannot prove the job passed on a commit.
6. A test declaration whose title is on the line after `it(` is not recognised (none of the cited tests is written that way).
7. The runbook's prose lines (the "Counts" sentence, the six-item mapping, notes) are hand-written and not machine checked; statuses, wording, rows and references are.
8. A PostToolUse hook from the typescript-patterns-enforcer plugin required no raw loops, no nested ternaries, no magic numbers and a comment above each regex; I complied (the code uses `forEach`/`flatMap` and avoids regexes except none remain).
9. Runbook sections were generated once from the data to avoid copying errors; the file is plain hand-maintainable markdown afterwards.
