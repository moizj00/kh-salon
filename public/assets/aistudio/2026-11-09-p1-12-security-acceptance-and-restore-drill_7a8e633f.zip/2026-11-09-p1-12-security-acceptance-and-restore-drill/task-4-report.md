# Task 4 report: append-only sweep

Status: DONE_WITH_CONCERNS (concerns are about the test runner and scope, not about the database).

Commit: `777e477` "tests: no role can change an append-only table (doc 06 10.2)" on `claude/p1-12-acceptance-guards`. One file: `supabase/tests/append-only-sweep.test.ts` (new). Nothing else touched.

## What was built

`appendOnlyTables()` asks the catalog (pg_trigger joined to pg_proc and pg_namespace) for every table in `public, control, app, supplier_vault, vault_api` with a non-internal, row-level BEFORE trigger on UPDATE and DELETE that calls `control.forbid_mutation` (the append-only function in `20261024223304_foundation.sql` line 369). No hand-typed list.

Only one append-only function exists. A catalog test (`prosrc ~* 'append-only'` over the five schemas) asserts it is the only one, so a second variant fails the build instead of hiding tables from the sweep. No other differently named function was found; no function was added to the list. `control.no_delete`, `master_row_guard`, `approval_guard` and others guard state changes, not append-only, and are out of scope.

Tables found (46, on the migrated embedded Postgres):
control.audit_event, control.phone_reveal, public.cash_ledger_entry, commission_payment, credit_event, delivery, delivery_line, delivery_signature, delivery_signature_access, delivery_signature_image, delivery_signature_use, delivery_submission, delivery_submission_decision, demand_signal, handover, handover_response, handover_settlement, installment, investment, investor_payout, investor_profit_decision, invoice, invoice_draft_version, invoice_snapshot, order_intake_card, order_intake_card_close, order_intake_card_line, order_intake_card_version, owner_stock_adjustment, payment, payment_allocation, payment_reversal, pending_stock_resolution, receipt, rep_commission_rate, route, sales_order_line, salon_approval_decision, salon_note, salon_rep_assignment, salon_sku_price, sku_price_change, stage_event, stock_count, stock_movement, visit.
None are in app, supplier_vault or vault_api. The existing hand list in crm-attacks (14) is a subset.

13 tests:
1. Catalog finds the tables; known tables present; at least 40 (not vacuous).
2. `control.forbid_mutation` is the only function that raises the append-only error.
3. Gap guard `APPEND_ONLY_GAPS` is empty on the real schema: every table that is append-only by its trigger in any shape, or by a table comment containing "Append-only", has an enabled, row-level, BEFORE, UPDATE+DELETE trigger with no WHEN clause and no column list. The comment arm is what catches a table that lost its trigger completely (a trigger-only discovery cannot see that).
4. Catalog privilege check: rep, manager, owner (all `authenticated`), `anon`, `service_role` hold no UPDATE, DELETE or TRUNCATE (table or column level) on any of the 46 tables.
5-10. For each persona (rep A, rep B, manager, owner, anon, service_role) and each table: `UPDATE ... where false`, `DELETE ... where false`, `TRUNCATE` all raise SQLSTATE 42501 (6 x 46 x 3 = 828 statements).
11. The application-role refusal text is "permission denied".
12. Planted table with a real row: as postgres (holds all grants) UPDATE and DELETE are refused by the trigger; with the trigger disabled the same statements go through ("not refused"), so the refusal is the trigger's alone.
13. Planted-table guard test: the gap guard reports a planted table whose trigger is removed, disabled, replica-only, update-only, delete-only, AFTER, has a WHEN clause, has a column list, is statement-level, or calls a look-alike function in another schema; it does not report a correct trigger or an unrelated plain table.

## What is proven by what (honest scope)

- Application roles (rep, manager, owner, anon, service_role): proven by grant denial. `where false` never fires a row trigger, so these tests show the roles have no privilege, not that the trigger fires. Tests 4 and 11 state this explicitly.
- The trigger itself, for roles that do hold the grant (postgres): proven structurally for all 46 real tables (test 3: enabled, row-level, BEFORE, UPDATE and DELETE, unconditional) and behaviourally only on a planted table (test 12), because inserting a valid row into every real table generically is not possible (NOT NULL, FK, check constraints). Real-row trigger refusal on the 14 core tables remains in crm-attacks.test.ts ("even the table owner cannot UPDATE or DELETE ...") and foundation.test.ts (audit_event).
- TRUNCATE for postgres is not asserted. Several append-only tables have a `no_truncate` statement trigger, not all do (e.g. grep shows it on delivery, invoice, visit, stage_event; I did not find it on every one). Brief scopes TRUNCATE to the four application roles, so I did not add it. Worth a decision if doc 06 10.2 should cover the superuser/owner path.
- The sweep selects a table's first real column for the UPDATE (a nonexistent column raises 42703 before the privilege check, which I saw when probing with `id`).

## Real violations

None. All 46 tables pass; no table excluded. A mutation check on a clone confirmed the sweep is not vacuous: after `grant update on public.visit to authenticated`, `grant delete on public.payment to anon`, `drop trigger append_only on public.stage_event` and `alter table public.receipt disable trigger append_only`, the tests failed on exactly those four (privilege list, per-role sweeps for authenticated personas and anon, trigger gap guard naming stage_event and receipt). Those mutations were made in a throwaway database, not in a migration.

## Commands and results

RED (stage 1): `appendOnlyTables()` stubbed to throw `not implemented`, run `vitest run ... append-only-sweep`:
`append-only-sweep.test.ts (13 tests | 9 failed)`: the finder test, the privilege test, the six persona sweeps (8 from the stub) and the planted-guard test (1 from my own bug: `planted(guarded, APPEND_ONLY)` returned all 46 real tables plus the planted one; fixed by filtering to the planted name). Failure detail text was lost because of the runner problem below, so the stub failures are the reported reason, not quoted output.

GREEN:
```
KIRAN_TEST_DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:56050/kiran_r4 \
  pnpm exec vitest run --config supabase/tests/vitest.config.ts append-only-sweep --reporter=verbose
 Test Files  1 passed (1)
      Tests  13 passed (13)
   Duration  3.27s
```
All 13 listed with a check mark (finder, single-function, trigger gap guard, privilege catalog, 6 persona sweeps, grant-denial text, planted real-row, planted-guard).

`pnpm exec biome check supabase/tests/append-only-sweep.test.ts`: no fixes needed (after `--write` once). `pnpm exec tsc -p supabase/tests/tsconfig.json --noEmit`: exit 0, no output.

## Concern: `pnpm db:test -- <filter>` runs the WHOLE suite

`pnpm db:test -- append-only-sweep` forwards a literal `--` to vitest, which then ignores the filter and runs every test file. My file sorts first (ByName sequencer), so its result line prints and the run then continues through the entire suite (looks like a "hang"; it cost me several long runs and had the 3-minute-plus setup repeated). The correct single-file invocation is:
`pnpm exec vitest run --config supabase/tests/vitest.config.ts append-only-sweep`
(or `pnpm db:test append-only-sweep` without `--`; I did not run that form). The brief and task text both use the `-- name` form. Worth correcting in the plan and docs/ACTIVITY.md commands.

Other runner notes: embedded Postgres picks a random port in 55000-56999 and Windows reserves 55307-56007 (and others) on this machine, so a run can fail to bind. I ran my own embedded server on 56050 (scratch script, not in the repo, stopped afterwards) and cloned a pre-migrated template database per run via `KIRAN_TEST_DATABASE_URL`; the repo harness was not changed.

## Self-review

- Meets the brief: catalog-derived list, UPDATE/DELETE/TRUNCATE x rep/manager/owner/anon (plus second rep and service_role), planted guard test, no hand lists, no weakening, no exclusions.
- Style: the repo's TS-patterns hook forbids raw loops, magic numbers and uncommented regexes in new files; the file uses `.map/.flatMap/.reduce/it.each`, a named floor constant, and no regexes. The planted cases run sequentially (they share a table name).
- Limitations are stated above (grant-level proof for app roles; trigger structure for real tables; behaviour only on a planted table; postgres TRUNCATE not asserted).
- The "Append-only" comment arm of the gap guard depends on table comments containing the capitalised word. It matched the existing tables correctly (no false positives today). A table with a differently worded comment and no trigger would not be seen; that is a known blind spot of any non-trigger detection.
- Docs/logging: not edited (brief forbids). Controller needs to add the test title to the Task 3 index and the log entry.

## Fix round 1

Commit `8c117c5` "tests: append-only sweep sees "immutable" tables and tests the trigger arm alone". Only `supabase/tests/append-only-sweep.test.ts` changed.

### F1: the "immutable" wording and unprotected-by-comment tables
- Declared-by-comment is now `obj_description(...) ~* 'append[- ]only|immutable'` (shared const `DECLARED`), used by the gap guard and by a new `DECLARED_TABLES` query. On the real schema it finds 45 tables (the old case-sensitive match missed e.g. public.invoice, commented "Immutable"); every one has the BEFORE UPDATE OR DELETE row trigger, so no defect surfaced and nothing was excluded.
- New test: every declared table is in the trigger-found list (and public.visit "Append-only" plus public.invoice "Immutable" are both seen).
- The privilege check and the six persona sweeps now run over `sweptTables()` = trigger-found tables union declared tables (all from the catalog, no table list). They still pass: no application role holds UPDATE/DELETE/TRUNCATE on any of them.
- Function detector widened (`GUARD_FUNCTIONS`, body matches `append[- ]only|immutable`). That also finds 12 existing trigger functions that raise "... immutable" for a narrower rule (identity columns or a decided row; approval_guard, device_guard, investor_guard, invitation_guard, master_row_guard, sales_order_guard, salon_contact_guard, salon_guard, salon_membership_guard, salon_signup_request_guard, stock_issue_guard, user_profile_guard). They are not append-only guards (they let permitted updates through), so they are held in a reviewed list of 12 FUNCTIONS (not tables, `IDENTITY_GUARDS`); the test asserts the remainder is exactly `["control.forbid_mutation"]` and that no listed function has vanished. A new "immutable"-raising guard function fails the test until reviewed. This is the one new hand-written list; it names functions, as the instruction left open. Planted test: a new `public` guard function raising "immutable" or "append only" is seen; one raising "no way" is not.
- New comment-arm test: five wordings ("Append-only", "Immutable (doc 04)...", lowercase, "APPEND ONLY", "Immutable:") on a trigger-less planted table are each reported; an unrelated comment is not.

### F2: the trigger arm alone
New test with a COMMENT-LESS planted table: control (correct trigger) accepted; only BEFORE UPDATE, only BEFORE DELETE, disabled, and AFTER trigger are each reported. Only the trigger arm can see these.

### Commands and output
```
pnpm exec vitest run --config supabase/tests/vitest.config.ts append-only-sweep --reporter=verbose
 Test Files  1 passed (1)
      Tests  17 passed (17)
```
(KIRAN_TEST_DATABASE_URL pointed at a clone of a pre-migrated scratch database on my own embedded Postgres; the repo harness is unchanged.) `biome check` clean; `tsc -p supabase/tests/tsconfig.json --noEmit` exit 0.

Mutation A (trigger arm replaced by `or false`):
```
 Tests  1 failed | 16 passed (17)
 x the trigger arm alone: a damaged guard on a table with NO comment is still reported
```
Before this round, deleting that clause left every test green. Only the new test fails, as intended.

Mutation B (`DECLARED` back to the old `~ 'Append-only'`):
```
 Tests  2 failed | 15 passed (17)
 x every table that calls itself append-only or immutable has the trigger ...   expected [ 'control.phone_reveal', ...(43) ] to include 'public.invoice'
 x the comment arm: ... in any wording, but has no guard
```
Both mutations were applied to the file and then restored from a copy (`git status` clean after the commit).

### Found / concerns
- No commented append-only/immutable table is unprotected; nothing excluded.
- Remaining blind spot: a table with no trigger and a comment that uses neither word is still invisible to the gap guard (a catalog cannot know intent); the privilege sweep covers only tables found by trigger or comment.
