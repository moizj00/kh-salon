### Task 3: The acceptance index

**Files:**
- Create: `docs/runbooks/launch-security-acceptance.md`, `supabase/tests/launch-acceptance.test.ts`

**Interfaces:**
- Produces: `type Evidence = { kind: "test" | "ci" | "manual" | "blocked"; ref: string }` where `ref` is `path::exact test title` for `test`, a job name in `.github/workflows/ci.yml` for `ci`, the blocking task id (for example `P1-05`) for `blocked`, and a runbook path for `manual`; `ACCEPTANCE: { criterion: string; evidence: Evidence[] }[]` (criteria `06.10.1` to `06.10.8` and `07.5.1` to `07.5.6`); `checkEvidence(entry: { criterion: string; evidence: Evidence[] }, root: string): string[]` returns one message per broken reference.

- [ ] **Step 1: Write the failing tests:**
  - every `test` reference resolves: the file exists and contains the exact title string;
  - every `ci` reference names a job that exists in `ci.yml`;
  - every `manual` reference is a file that exists;
  - the markdown table in `launch-security-acceptance.md` lists exactly the criteria in `ACCEPTANCE`, in order;
  - a criterion with no evidence fails;
  - the guard itself: `checkEvidence` on a planted reference to a missing file returns a message (the guard is tested, not only run, as in `schema-hygiene.test.ts`);
  - a `blocked` entry is reported in the test output as blocked, never as passing.
- [ ] **Step 2: Run** `pnpm db:test supabase/tests/launch-acceptance.test.ts` — Expected: FAIL.
- [ ] **Step 3: Implement** the index with the mapping from the findings table above. Use the real titles from `rls-matrix.test.ts`, `foundation.test.ts`, `schema-hygiene.test.ts` and `device-guard.test.ts`; read them, do not paraphrase. Criteria 4 (items 2 to 6 of doc 07), 5 (mirror) and 6 are `blocked` with `P1-05`, a new task id for the mirror that MJ assigns, and `P1-08`. Criterion 7 is `manual` pointing at the drill runbook; criterion 8 is `ci` for `dependency-audit`, `secret-scan` and `typecheck + service-role scan`.
- [ ] **Step 4: Run** — Expected: PASS.
- [ ] **Step 5: Commit** `tests: launch security criteria mapped to evidence`.

