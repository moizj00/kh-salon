### Task 4: Append-only sweep (only if the gap is real)

**Files:**
- Create: `supabase/tests/append-only-sweep.test.ts`

**Interfaces:**
- Produces: `appendOnlyTables(): Promise<string[]>` returning every table in the five schemas that has a trigger calling the append-only function (read its exact name in `supabase/migrations/20261024223304_foundation.sql` near line 374).

- [ ] **Step 1: Check the gap.** Read `rls-matrix.test.ts` around the per-operation cases and `schema-hygiene.test.ts`. If a test already enumerates append-only tables and attempts UPDATE, DELETE and TRUNCATE as each application role, do not write this task: add that test's title to the Task 3 index and record the finding in the log.
- [ ] **Step 2: Write the failing tests:** for every table from `appendOnlyTables()` and each role in `rep`, `manager`, `owner` and `anon`, UPDATE, DELETE and TRUNCATE all raise (either `permission denied` or the append-only message); a planted table with the trigger removed is reported (the guard is tested).
- [ ] **Step 3: Run** `pnpm db:test supabase/tests/append-only-sweep.test.ts` — Expected: FAIL (module missing).
- [ ] **Step 4: Implement**, using the persona helpers the matrix uses.
- [ ] **Step 5: Run** — Expected: PASS. A real violation found is a defect: report it, do not weaken the test.
- [ ] **Step 6: Commit** `tests: no role can change an append-only table (doc 06 10.2)`.

