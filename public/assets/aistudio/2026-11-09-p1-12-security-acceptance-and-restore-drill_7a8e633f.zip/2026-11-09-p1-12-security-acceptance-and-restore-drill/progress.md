# SDD ledger — plan: docs/plans/in-progress/2026-11-09-p1-12-security-acceptance-and-restore-drill.md

Branch: claude/p1-12-acceptance-guards, cut from origin/main 727ebb3; plan cherry-picked as 06ab229.
Scope of this run: PR B of the plan (Tasks 3, 4, 5). Spec: docs/06-security-plan.md section 10, docs/07 section 5.

## Pre-flight scan

| Tasks | Produces / consumes | Finding |
|---|---|---|
| 3 vs 1, 2 | Task 3 step 3 maps criterion 8 to ci jobs `dependency-audit` and `secret-scan`, which Tasks 1 and 2 (PR A) create; Task 3's own test requires every ci ref to exist | Conflict when PR B is built before PR A |
| 3 vs 4, 5 | Task 3 index should cite the guards of Tasks 4 and 5 for criteria 2 and 3 | Order: run 4, 5, then 3 |
| 4 self | Step 1 says skip the task if an existing test already sweeps every append-only table | crm-attacks.test.ts has a hand-written APPEND_ONLY list (14 tables) and a trigger check; not a catalog sweep, later tables (payment, handover, commission...) are covered file by file. Gap is real: no test derives the list from the catalog |
| 5 self | agrees with itself | — |
| 3 self | agrees with itself | — |
| Global | "20 newest log entries" in plan header vs ACTIVITY section 4 (5 newest for the area, MJ 2026-11-10) | ACTIVITY wins |

Ruling: build PR B before PR A; in the index, criterion 06.10.8 cites the existing ci job for the service-role scan and marks the dependency and secret scans `blocked` on "P1-12 PR A" — the plan forbids stacked PRs and nothing may be claimed that no check proves — if wrong, one index row is edited when PR A lands.
Ruling: task order 4, 5, 3 — the index must cite real guard titles — no cost.
Ruling: Task 4 is built (gap real, see table) — if wrong, one redundant test file.
Ruling: the Antigravity coordinator's brief asked for one file supabase/tests/security-acceptance.test.ts with six proofs; MJ's own reviewed plan is the higher authority, so the six proofs are met by the index (Task 3) citing existing tests plus the two guards, not by a new file duplicating them — if wrong, a thin file re-running those cases is added later.
Ruling: implementers run only their own test file (pnpm db:test -- <file>), never the whole suite — the host is short of memory (memory note) — the full suite runs once in parts at the end.

## Tasks
Task 4: implemented, commit 06ab229..777e477 (13/13 on its own file, 46 append-only tables found, no violation); DONE_WITH_CONCERNS; task review dispatched.
Task 4: note — `pnpm db:test -- <name>` does not filter (runs the whole suite); single file is `pnpm exec vitest run --config supabase/tests/vitest.config.ts <name>`. Carried into later dispatches; CLAUDE.md's "pnpm db:test -- -t name" line is to be reported to MJ, not edited here.
Task 4: minor (deferred): a table that lost its trigger is detected through its "Append-only" comment only.
Task 5: implementer dispatched, BASE 777e477.
Task 4: review — spec PASS, quality Changes required. Open (Important): F1 gap detection misses an uncommented or differently worded ("Immutable") append-only table, match is case-sensitive; F2 the trigger arm of the guard is never tested alone (planted table always has the comment). Minor (deferred): TRUNCATE trigger structure not checked; 42501 not distinguished for TRUNCATE; floor assertion only in test 1; RED evidence thin.
Task 4: fix round 1 waits until the Task 5 implementer has committed (one writer in the checkout at a time).
Task 5: implemented, commit 777e477..2590bed (14 passed, 1 expected fail; 187 functions swept, 14 allowlisted); DONE_WITH_CONCERNS; one genuine finding kept as it.fails DEFECT CHECK: app.warehouse_availability() readable by owner or manager at AAL1. Task review dispatched.
Task 4: fix round 1 dispatched (F1, F2), FIX_BASE 2590bed.
Task 5: review — spec PASS, Changes required. Open (Important): G1 self_ok and rep_device_ok count as full gates though true for office at AAL1, so a new office-only function gated only by self_ok passes the sweep (criterion 3 not guarded structurally); G2 the DEFECT CHECK it.fails stays green if the fix makes the function raise at AAL1. Minor (deferred): policy check is per expression not per OR branch; GATE_DEFS needs are mention-level; gate named in a dollar-quoted string or with ignored result still counts.
Ruling: G1 is fixed now, not recorded as a known limit — the guard exists to protect criterion 3 for new functions — costs one more fix round.
Task 5: fix round 1 waits for the Task 4 fixer to commit (one writer at a time).
Task 4: fix round 1/5 fix committed 2590bed..8c117c5 (17/17 on its file; mutation runs recorded); scoped re-review dispatched.
Task 5: fix round 1 dispatched (G1, G2), FIX_BASE 8c117c5.
Task 4: fix round 1/5 (2 addressed, 0 open; commits 2590bed..8c117c5). Minor (deferred): function detector is a word match; identity-guard allow-list keyed by name; title wording at line 137.
Task 4: complete (commits 06ab229..777e477 and 8c117c5, review clean)
Task 5: fix round 1/5 fix committed 8c117c5..23807fa (18 passed, 1 expected fail); scoped re-review dispatched.
Task 3: implementer dispatched, BASE 23807fa.
Task 5: fix round 1/5 (2 addressed, 0 open; commits 8c117c5..23807fa). Minor (deferred): `is distinct from 'rep'` matched as text regardless of direction (allowing form would clear); `= 'rep' then raise` also counts as a marker; planted stringmark case does not really test string stripping; perform my_bag_id() counts as a marker; header says REP_MARKERS, constant is REP_MARKER_CALLS.
Task 5: complete (commits 777e477..2590bed and 23807fa, review clean)
Task 3: implemented 23807fa..ef16247 (14 passed, 11 todo; criteria 14: met 3, partial 5, blocked 5, open defect 1, plus ADD.1 and ADD.2 met); DONE_WITH_CONCERNS; task review dispatched.
