### Task 5: Every rep-callable function passes a gate

**Files:**
- Create: `supabase/tests/function-gates.test.ts`

**Interfaces:**
- Produces: `GATES: string[]` (the gate helpers found by reading the migrations, for example `app.assert_actor_ready`, `app.self_ok`, `app.assert_office`); `ALLOWLIST: { fn: string; reason: string }[]`.

- [ ] **Step 1: Find the gates.** `grep` the migrations for how existing `app.*` functions check actor, device and role; write the final `GATES` list from that, not from this plan.
- [ ] **Step 2: Write the failing tests:** every function in schema `app` that `authenticated` can execute has a body (`prosrc`) containing at least one `GATES` entry, or appears in `ALLOWLIST` with a reason; every `ALLOWLIST` entry still exists and still lacks a gate (a stale entry fails); a planted function without a gate is reported.
- [ ] **Step 3: Run** `pnpm db:test supabase/tests/function-gates.test.ts` — Expected: FAIL.
- [ ] **Step 4: Implement.** Expected allowlist: functions that must work before a device exists (for example `register_device`, `my_session`); every entry needs a reason a reviewer can check against the function.
- [ ] **Step 5: Run** — Expected: PASS. A function with no gate and no good reason is a finding for MJ.
- [ ] **Step 6: Commit** `tests: a new function cannot skip the device and role gate`. Open PR B.

