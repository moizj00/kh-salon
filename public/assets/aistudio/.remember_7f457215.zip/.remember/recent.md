# Recent

## 2026-11-03
Fixed a stale refused-request test and a SQL migration (`20261106030000`) that filtered after `limit 1`; the H1 DB tests pass only with the migration, and typecheck/lint were pending. On `feat/p0-foundation`, PRs 15, 41, and 42 merged to main (C-014 slices 1–3 and B-34/B-35 fixes, including migration 0019), but slices 1–3 remain unverified until a fresh verifier re-checks the merged code. Open items: the required-check ruleset change, B-31 (a/c/d/e), the task-ID mapping for slices 1–2, MFA page access (#8), and a pending "only MJ can merge" rule change.

## Identity Candidates
- (none)