# 2026-11-05 04:00 PKT · Claude · Opus 5.5 · branch claude/p1-18-invitations · TASK
**Task:** P1-18 (completion slice 1; SEC-13, SEC-16, SEC-17, SAL-11, SAL-13, SAL-14; D-35, D-36, D-39, D-41; areas: invitation, salon_membership, salon_approval_decision, salon_rep_assignment, salon.approval_status, app.rep_holds_salon, app.rep_can_reach_salon, app.my_salons, app.my_salon, app.due_list, app.my_route, app.build_order, app.office_create_order, app.rep_create_card, control.salon_guard, /invite, /salon, /office/people, /office/salons/approvals, the office salon page, proxy.ts, supabase/config.toml, the stack seed and stack test)
**What / why:** Slice 1 of the project completion plan (docs/superpowers/plans/2026-11-05-project-completion.md), stacked on branch claude/spec-reps-salons-orders (slice 0, open pull request).

Database, migration 20261105100000_invitations_salon_approval.sql:
- public.invitation: the owner or a manager invites a rep or a salon (app.office_invite, AAL2). The token is 32 bytes from pgcrypto gen_random_bytes (the migration creates the extension in schema extensions if missing), returned once as hex; only its sha256 is stored. Single use, 7 days, bound to the email. A replay of the client_id returns the invitation with a null token. One live invitation per email and per salon. Owners and managers cannot be invited this way (42501, for the owner too). A salon invitation names an approved salon or creates one, approved, through app.create_salon in the same call; a new-salon id already in use is refused (23505), because create_salon would hand an existing salon back to its creator and so skip the one-live-invitation-per-salon check. The table has no grant to any API role; the office lists it with app.office_invitations (no token data) and revokes with app.office_revoke_invitation.
- app.redeem_invitation: compares the token hash and the session login's confirmed email in auth.users, and requires the signed amr claim to show an emailed code (otp or magiclink). An unknown token and another email get the same 22023 words. Used, revoked and expired are 55000; the same login's replay changes nothing. A rep invitation creates the user_profile (role rep, the invitation's name, no vault grant); a salon invitation creates the salon_membership, never a role. Redeeming clears any password on the login and ends its other sessions (see the DEVIATION entry 2026-11-05-claude-p1-18-signup).
- app.invitation_preview: who invited whom for what, after the code only (no function runs for anon, schema-hygiene).
- app.office_set_member_status: the owner or a manager sets a rep active or suspended (devices revoked at once) and a salon account active, suspended or revoked. Offboarding, role changes and anyone not a rep stay with the owner on the existing owner functions. Rows locked before the check.
- salon.approval_status (pending, approved, rejected; existing rows approved by the column default), changed only with a salon_approval_decision row in the same transaction (control.salon_guard). app.office_decide_salon (once per salon; reject needs 5 to 500 characters; optional rep and rate in basis points, 0 to 10000), app.office_assign_salon_rep (append-only, latest row by seq wins, null clears), app.office_pending_salons.
- R4: app.rep_holds_salon(rep, salon) is the single rule: the latest direct assignment's rep only, else territory coverage. app.rep_can_reach_salon keeps its device and role checks and uses it; app.my_salons, app.my_salon, app.due_list and app.my_route now use it instead of their inline territory test; app.office_set_route already did; app.office_create_order uses it for the delivering rep (A-16) and refuses another rep on a directly assigned salon. Still territory-based: app.office_receivables_ageing per rep (A-14, confirmed by MJ L-0361), which now disagrees with a direct assignment; changing it is MJ's call.
- A pending or rejected salon gets no order (app.build_order, 55000) and no order card (app.rep_create_card, 55000).
- app.salon_me: the caller's own active membership, allow-listed fields (name, address, approval_status, membership_status), null otherwise.

Web: /invite/[token] (the only shouldCreateUser true; email, code, then the preview and Accept; no referrer), /salon (salon_me and a pending notice) and /salon/login (shouldCreateUser false), /office/people (invite with the link shown once and a copy button; invitations with revoke; reps and salon accounts with suspend, reactivate, revoke), /office/salons/approvals (approve with an optional rep and a rate in percent, or reject with a reason), rep and rate on the office salon page, nav links, order form offers only the directly assigned rep and approved salons. proxy.ts sends a signed-out /salon visitor to /salon/login and only refreshes the session on /invite.

Config: supabase/config.toml enable_signup = true with the reason; the Team page comment updated.

Docs: doc 04 (built rows and columns), doc 06 (section 2 rows and 2.1 note), doc 12 status notes on D-35, D-36, D-39, SPEC.md, CLAUDE.md and AGENTS.md (identical), ACTIVITY section 1 and H-15 parentheticals (what slice 1 built) and the board row P1-18 set to IN PROGRESS (implemented, awaiting CI including the e2e-stack browser test, and an independent check). In the master prompt's words this is IMPLEMENTED — NOT VERIFIED; the board cannot say so, because Appendix C rule 4 refuses a changed Status cell that mentions VERIFIED other than a VERIFIED citation, and section 6 allows DONE (self-reported) only after CI has passed.

Rulings made here (safest reading, none invents a business rule): the preview shows only after the code; the amr proof, the password clearing and the session ending at redeem; a salon is decided once, so a rejected proposal is final; only an approved salon is assigned or invited; a suspended directly assigned rep leaves the salon unreachable until the office reassigns it (no fallback to the territory); a new salon from an invitation still needs an area and a type (salon.area_id is not null), so R4's no-area case cannot arise yet; reps keep creating approved salons until slice 7; the rep card refusal for pending salons follows spec section 3.
**Evidence:** Branch claude/p1-18-invitations from claude/spec-reps-salons-orders 569da9e, which is already in main (merge-base with origin/main cd26f74 is 569da9e). Commits e6a28f3 (database and tests), 6af1a59 (web, config, seed, stack test), 0b05b38 (docs and this entry), and a follow-up commit (new-salon id pre-check and its test, the suspended-assigned-rep test, stack test diagnostics, this entry's corrections). DATABASE_URL unset; embedded Postgres 17, one test file at a time.

Test first: pnpm db:test salon-approval before the migration: 42 failed, 4 passed (functions missing).

After the migration, each command once unless noted:
- pnpm db:test invitations: 91 passed (first run failed setup with No test files found and Unknown Error, the known flake, rerun; a second run failed 2 on a sweep size floor of 50 when the schemas hold 49 relations, floor set to 40, then 91 passed; rerun on the final migration below).
- pnpm db:test salon-approval: 46 passed (one earlier run failed 1 on a bad route_stop_reason in the test, fixed in the test).
- pnpm db:test rls-matrix: 1963 passed (one setup flake first, rerun).
- pnpm db:test schema-hygiene: 13 passed. pnpm db:test verifier-attacks: 36 passed.
- pnpm db:test orders.test (orders and office-orders): 65 passed; office-orders: 21 passed; order-cards: 27 passed.
- pnpm db:test salons.test: 21 passed; visits.test: 14 passed; verify-slices-1-3.test (matched verify and reverify-slices-1-3): 40 passed.
- pnpm db:test crm-attacks.test: 57 passed, 1 failed (anon held default privileges on the new identity sequence salon_rep_assignment_seq_seq); fixed in the migration by revoking the sequence; rerun on the final migration below.
- rls-matrix, verifier-attacks, orders, office-orders, order-cards, salons, visits and verify-slices-1-3 ran on the working tree before the sequence revoke was added; that revoke is the only difference between what they ran on and e6a28f3.
- On e6a28f3 itself: crm-attacks 58 passed; invitations 91 passed; salon-approval 46 passed; schema-hygiene 13 passed.
- On the follow-up commit (the new-salon id pre-check in the migration, one new test in each file): see the addition at the end of this entry.
- The filter verify-slices-1-3.test also matched reverify-slices-1-3.test.ts, so that reverify suite ran locally, against the instruction to leave reverify suites to CI; it passed (part of the 40).
- pnpm typecheck: pass (supabase tests, apps/web, packages/import). pnpm lint: pass, 33 warnings and 42 infos, the same counts as slice 0.
- pnpm -C apps/web build with the CI placeholder public settings: pass; routes include /invite/[token], /salon, /salon/login, /office/people, /office/salons/approvals.
- node scripts/service-role-scan.mjs --bundle apps/web/.next/static: OK, 106 files. pnpm service-role:scan: OK, 67 files. node --check scripts/e2e-stack-seed.mjs: exit 0.
- CI=true pnpm -C apps/web test:e2e: 4 passed.

Not run here: apps/web/e2e-stack (no Docker on this host; CI only), so the auth guard re-pin and the new journey are unexercised, including the amr method name GoTrue writes for verifyOtp type email (otp is expected; magiclink is also accepted). The reverify suites other than reverify-slices-1-3 (CI runs them). Nothing touched staging or production; synthetic data only.

Stack test approach: the suite already reads codes from Mailpit, and the local stack sends at most 2 emails an hour, one of which the rep journey spends. So the salon invitee goes through the real /invite page and code from Mailpit, and the rep invitee's link is redeemed on the local database with a session made the way the seed acts for people (claims with an otp amr); the page is the same page.

DoD (section 6):
[x] Requirement IDs implemented as written, or the difference logged (DEVIATION 2026-11-05-claude-p1-18-signup)
[x] Migration forward-only; applies on a fresh embedded database with every earlier migration
[x] New tables: RLS enabled and forced, policies, matrix rows for every persona
[x] Append-only tables refuse UPDATE and DELETE, tested even as the table owner
[x] Mutations through security definer functions, pinned search_path, client_id replay tested
[x] Audit rows produced with the session's actor; the chain verifies
[x] No vault data involved
[ ] Offline: not applicable to office and invite screens; rep offline unchanged
[x] Money: rate in integer basis points
[ ] Lint, typecheck, touched DB suites pass locally; CI not yet run (so not DONE)
[x] Docs and board updated
[x] No secrets, real personal or supplier data in the diff (read)
[x] This entry holds the evidence

Security checklist (tick honestly):
[x] RLS enabled+forced; policies + role×table tests added/updated (H-13)
[x] Append-only respected; UPDATE/DELETE denied for all app roles (H-06, H-07)
[x] Mutations via SECURITY DEFINER fn, pinned search_path, idempotent (H-08)
[x] Audit trigger present; hash chain verifies (H-17)
[x] No vault/supplier/cost data outside vault; leakage tests pass (H-01, H-05)
[x] No secrets / real personal data / real supplier data in the diff (H-02, H-03, H-20)
[x] Governance powers still owner-only + AAL2 (H-15)
[x] No control weakened, skipped or "temporarily" disabled (H-16)
[x] Docs match code; deviations logged (H-25)
[x] Tests actually run; real results recorded (H-23, H-24)

The header time was not read from a clock: the session date is 2026-11-05, while the host clock read 2026-11-04 22:54 PKT.

CI and merging: a read-only trial merge with origin/main (git merge-tree) is clean; main gained only .github/workflows/ci.yml (reserved Supabase ports) and one log file since 569da9e, and neither is touched here. node scripts/activity-log-check.mjs origin/main fails only because that log file is absent from this branch (seen as deleted); against the merge-base 569da9e it passes. In CI the pull request's merge ref includes the file.
Addition, on the follow-up commit: pnpm db:test invitations.test: 92 passed; pnpm db:test salon-approval.test: 47 passed (the one new test in each). pnpm typecheck: pass (it overlapped the last DB run). pnpm lint: pass, 33 warnings, 42 infos. node --check scripts/e2e-stack-seed.mjs: exit 0. The other suites were not rerun on the follow-up commit: its migration change adds one refusal inside app.office_invite, which no other suite calls.
Addition, CI on PR 56 at ba132d7 (job migrations + RLS matrix, the whole suite in one shared database): 38 of 39 files passed, 2826 tests, 1 failed: visits.test.ts, a visit before check-in is refused (log_visit succeeded). Cause: salon-approval.test.ts, in the test that a rep's card for a pending salon is refused, committed a rep_day row for rep A for today, so every later file found rep A checked in. Locally each file ran alone, which hid it. Fix (the commit after ba132d7): that rep_day insert and the card call now run in one rolled-back transaction; and the file's afterAll clears every direct assignment it left on its own salons, so rep A and rep B leave with the reach other files expect. No assertion was loosened.

Checks, embedded Postgres, one vitest command each, files sharing one database in name order:
- Reproduced with salon-approval.test.ts as at ba132d7: pnpm exec vitest run --config supabase/tests/vitest.config.ts salon-approval.test visits.test: 1 failed (visits, a visit before check-in is refused), 60 passed.
- With the fix: the same command over invitations.test salon-approval.test visits.test: 3 files, 153 passed.
- With the fix, in the branch's own worktree: invitations.test salon-approval.test crm-attacks.test orders.test deliveries.test payments.test handovers.test salons.test visits.test (orders.test also matched office-orders): 10 files, 408 passed (one earlier attempt hit the known No test files found and Unknown Error setup flake and was rerun).
- Biome check and tsc on the test file: clean.
**Next / needs:** CI on the pull request, especially the e2e-stack job (the amr method name, the password self-signup re-pin, the invite journey). MJ: whether to turn enable_confirmations on at go-live (it would also need a confirmation email template carrying the code); MJ turns email signup on for the hosted projects (spec section 8). Then slice 2 (P1-19).
